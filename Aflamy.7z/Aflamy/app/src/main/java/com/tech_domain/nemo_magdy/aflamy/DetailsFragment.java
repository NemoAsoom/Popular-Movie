package com.tech_domain.nemo_magdy.aflamy;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.ShareActionProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.squareup.picasso.Picasso;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieData;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieHelper;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieSchema;
import com.tech_domain.nemo_magdy.aflamy.related_data.TrailersKeyNames;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Nemo_Magdy on 9/15/2016.
 */
public class DetailsFragment extends Fragment {

    String _title, _rate, _date, _overview, _posterPath, _reviews, _movID;
    TextView Title, Rate, Date, Overview, Reviews;
    ImageView Poster;
    String posterURL = "http://image.tmdb.org/t/p/w185/";
    ListView tailerListView;
    ArrayList<String> array_keys_film ;
    ArrayList<String> array_name_film;
    ArrayList<TrailersKeyNames> trailersKeyNames;
    ArrayList<String> trialerKeyNameURLs;
    ArrayList<String> trial;
    ToggleButton addFavoriteButton;
    MovieHelper myHelper;
    SQLiteDatabase db ;
    ProgressDialog loading ;
    View view;
    public DetailsFragment() {
        setHasOptionsMenu(true);
    }


    public static DetailsFragment getInstanceFrag(MovieData movie){
        DetailsFragment detailsFragment = new DetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("mybundle",movie);
        detailsFragment.setArguments(bundle);

        return detailsFragment;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_details, container, false);
        array_keys_film = new ArrayList<>();
        array_name_film = new ArrayList<>();
        trailersKeyNames = new ArrayList<>();
        trialerKeyNameURLs = new ArrayList<>();
        trial = new ArrayList<>();

        Title = (TextView) view.findViewById(R.id.movieTitleInDetail);
        Rate = (TextView) view.findViewById(R.id.movieRate);
        Date = (TextView) view.findViewById(R.id.movieDate);
        Overview = (TextView) view.findViewById(R.id.movieOverview);
        tailerListView = (ListView) view.findViewById(R.id.trailers_list);
        Reviews = (TextView) view.findViewById(R.id.movieReviews);
        addFavoriteButton = (ToggleButton) view.findViewById(R.id.action_add_favourite);
        Poster = (ImageView) view.findViewById(R.id.moviePosterInDetail);
        myHelper = new MovieHelper(getActivity());
        db = myHelper.getReadableDatabase();
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        Log.i("m",getArguments()==null?"y":"n");


        MovieData film = getArguments().getParcelable("mybundle");

        _title = film.getTitle();
        _rate = String.valueOf(film.getRate());
        _date = film.getDate();
        _overview = film.getOverview();
        _posterPath = film.getPosterLink();
        _movID = film.getMov_id();

        Title.setText(_title);
        Rate.setText(_rate);
        Date.setText(_date);
        Overview.setText(_overview);

        addToFavorite();

        if(film.getPoster() == null){
            Picasso.with(getContext()).load(posterURL +_posterPath).into(Poster);
        }else {
            Poster.setImageBitmap(film.getPoster());
        }

        if(film.getTrialers_name() == null&& film.getReviews() == null){
            StartTasks();
        }
        else{
            try {
                JSONObject json = null;
                try {
                    json = new JSONObject(film.getTrialers());

                    JSONArray items = json.optJSONArray("uniqueArrays");
                    for (int i = 0; i < items.length(); i++) {
                        String id_trial = items.optString(i);
                        array_keys_film.add(id_trial);
                        System.out.println("trial      " + array_keys_film.get(i));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    json = new JSONObject(film.getTrialers_name());

                    JSONArray items = json.optJSONArray("Arrays");
                    for (int i = 0; i < items.length(); i++) {
                        String id_trial = items.optString(i);
                        array_name_film.add(id_trial);
                        System.out.println("trial      " + array_name_film.get(i));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                film.setTrialers("");
                film.setTrialers_name("");
            }
            TailerListAction();

            if(film.getReviews()!= null ){
                Reviews.setText(film.getReviews());
            }else{
                Reviews.setText("This Movie haven't reviewed yet!!");
            }
        }
    }

    private void StartTasks(){
        FetchReviews reviewsTask = new FetchReviews();
        FeatchTrailers trailerTask = new FeatchTrailers();
        trailerTask.execute();
        reviewsTask.execute();
    }

    private void addToFavorite(){
        int movie_id = 0 ;
        Cursor c = db.query(false , MovieSchema.TABLE_NAME , new String[]{"mov_id"} , "mov_id=?" ,new String[]{_movID}  , null , null ,null , null);
        if(c.moveToFirst()){
            do {
                int index_id = c.getColumnIndex("mov_id");
                movie_id = c.getInt(index_id);
            }while (c.moveToNext());
        }
        if(movie_id != 0){
            addFavoriteButton.setChecked(true);
        }else{
            addFavoriteButton.setChecked(false);
        }

        addFavoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _reviews = Reviews.getText().toString();
                if (addFavoriteButton.isChecked()) {
                    if(Poster == null){
                        Toast.makeText(getActivity(), "Loading Poster...", Toast.LENGTH_SHORT).show();
                    }
                    Drawable d = Poster.getDrawable();

                    Bitmap image_movie =((BitmapDrawable) d).getBitmap();
                    byte image_byte[]=getBytes(image_movie);

                    JSONObject json = new JSONObject();
                    try {
                        json.put("uniqueArrays", new JSONArray(array_keys_film));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String trials_key = json.toString();

                    JSONObject json_name = new JSONObject();
                    try {
                        json_name.put("Arrays", new JSONArray(array_name_film));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String trials_name = json.toString();

                    ContentValues values = new ContentValues();
                    values.put(MovieSchema.COL_MOVIE_ID, _movID);
                    values.put(MovieSchema.COL_RATE, _rate);
                    values.put(MovieSchema.COL_DATE, _date);
                    values.put(MovieSchema.COL_TITLE, _title);
                    values.put(MovieSchema.COL_OVERVIEW, _overview);
                    values.put(MovieSchema.COL_REVIEWS, _reviews);
                    values.put(MovieSchema.COL_TRAILERS_KEY,trials_key);
                    values.put(MovieSchema.COL_TRAILERS,trials_name);
                    values.put(MovieSchema.COL_POSTER ,image_byte );


                    long row = db.insert(MovieSchema.TABLE_NAME, null, values);
                    if (row > 0) {
                        Toast.makeText(getActivity(), row + "Movies in Favorite", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    db.delete(MovieSchema.TABLE_NAME , "mov_id=?" ,new String[]{_movID} );
                    Toast.makeText(getActivity(), "one Movie Removed from Favorite", Toast.LENGTH_SHORT).show();
                }



            }
        });

    }

    public class FetchReviews extends AsyncTask< Void, Void, String>{
        String Reviews;

        @Override
        protected String doInBackground(Void... voids) {
            HttpURLConnection urlConnection =null ;
            String ID= "1962bc00de1584940b4f338dc55d6887";
            String result_array = null ;


            try {
                String BASE_URL = "http://api.themoviedb.org/3/movie/"+_movID+"/reviews?";
                String ID_BARAM = "api_key";

                Uri build_uri = Uri.parse(BASE_URL).buildUpon()
                        .appendQueryParameter(ID_BARAM , ID) .build();

                URL url = new URL(build_uri.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();




                InputStream inputStream =  urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line ;

                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() == 0) {
                    return null;
                }
                result_array = buffer.toString();

                JSONObject dataJson = new JSONObject(result_array);
                JSONArray filmArray = dataJson.getJSONArray("results");

                for(int i = 0 ; i<filmArray.length() ; i++) {
                    JSONObject filmData = filmArray.getJSONObject(0);
                    Reviews = filmData.getString("content");
                    Log.i("out   "+0+" :  " , Reviews);
                }

                if (urlConnection != null) {
                    urlConnection.disconnect();
                }     if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("error", "Error closing stream", e);
                    }
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return Reviews;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DetailsFragment.this.Reviews.setText(Reviews);
        }

    }

    public class FeatchTrailers extends AsyncTask< Void, Void, ArrayList<TrailersKeyNames>>{

        protected void onPreExecute() {
            try {
                loading = ProgressDialog.show(getActivity() , "Aflamy" , "loading Details" , true , true);
            }catch (Exception e){
            }
            super.onPreExecute();
        }

        @Override
        protected ArrayList<TrailersKeyNames> doInBackground(Void... voids) {
            HttpURLConnection urlConnection =null ;
            String ID= "1962bc00de1584940b4f338dc55d6887";
            String result_array = null ;
            array_keys_film = new ArrayList<>();


            try {
                String BASE_URL = "http://api.themoviedb.org/3/movie/"+_movID+"/videos?";
                String ID_BARAM = "api_key";

                Uri build_uri = Uri.parse(BASE_URL).buildUpon()
                        .appendQueryParameter(ID_BARAM , ID) .build();

                URL url = new URL(build_uri.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();




                InputStream inputStream =  urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line ;

                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() == 0) {
                    return null;
                }
                result_array = buffer.toString();

                JSONObject dataJson = new JSONObject(result_array);
                JSONArray filmArray = dataJson.getJSONArray("results");

                for(int i = 0 ; i<filmArray.length() ; i++) {
                    JSONObject filmData = filmArray.getJSONObject(i);
                    String key = filmData.getString("key");
                    String name = filmData.getString("name");

                    array_keys_film.add(key);
                    array_name_film.add(name);
                    trailersKeyNames.add(new TrailersKeyNames(array_name_film , array_keys_film)) ;
                    Log.i("out   "+i+" :  " , key);

                }

                if (urlConnection != null) {
                    urlConnection.disconnect();
                }     if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("error", "Error closing stream", e);
                    }
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return trailersKeyNames ;

        }

        @Override
        protected void onPostExecute(ArrayList<TrailersKeyNames> strings) {
            super.onPostExecute(strings);
            TailerListAction();
            loading.dismiss();
        }

    }

    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
}

    public void TailerListAction(){
        if(getActivity() != null){
            ArrayAdapter<String > adapter = new ArrayAdapter<String>(getActivity() , android.R.layout.simple_list_item_1 , array_name_film);
            tailerListView.setAdapter(adapter);
        }
        tailerListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(array_keys_film.size() != 0){
                    Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube://"+array_keys_film.get(i)));
                    if (in.resolveActivity(getActivity().getPackageManager()) != null) {
                        startActivity(in);
                    } else {
                        Toast.makeText(getActivity(), "Install youtube and try again Later!!", Toast.LENGTH_SHORT).show();
                    }
                }
            }});
    }

    ShareActionProvider mShareActionProvider ;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.share, menu);
        MenuItem menuItem = menu.findItem(R.id.action_share);
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(menuItem);
        mShareActionProvider.setShareIntent(createShareForecastIntent());
    }

    private Intent createShareForecastIntent() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        shareIntent.setType("text/plain");
        if(array_keys_film.size() != 0){
            shareIntent.putExtra(Intent.EXTRA_TEXT, "https://www.youtube.com/watch?v="+array_keys_film.get(0) );
        }

        return shareIntent;
    }


}