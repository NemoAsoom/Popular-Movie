package com.tech_domain.nemo_magdy.aflamy;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.tech_domain.nemo_magdy.aflamy.related_data.MovieData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MainActivityFragment.myInterface {

    boolean flag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(findViewById(R.id.fram_detail)==null){
            flag=false;
        }else{
            flag =true;
        }
    }

    @Override
    public void inMethod(MovieData film) {
        if(flag){
            DetailsFragment detailsFragment = DetailsFragment.getInstanceFrag(film);
            getSupportFragmentManager().beginTransaction().replace(R.id.fram_detail,detailsFragment).commit();
        }else{
            Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
            intent.putExtra("mybundle",film);
            startActivity(intent);

        }
    }
}
